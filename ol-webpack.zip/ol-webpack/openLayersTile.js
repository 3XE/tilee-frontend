import {Map, View} from 'ol';
import TileLayer from 'ol/layer/Tile';
import XYZ from 'ol/source/XYZ';
import VectorLayer from 'ol/layer/Vector';
import Point from 'ol/geom/Point';
import Polygon from 'ol/geom/Polygon';
import Feature from 'ol/Feature';
import { isEmpty } from 'ol/obj';
import {Vector} from 'ol/source';
import Projection from 'ol/proj/Projection.js';
import {Circle as CircleStyle, Fill, Stroke, Style} from 'ol/style.js';
import convert from './src/blah';
//var firstName = .getElementById("myNo").value;
//console.log(firstName);
/*
ThingClass

DiamondThing extends ThingClass
  getNumberToCover(targetSurface)

SquareThing extends ThingClass
  getNumberToCover(targetSurface)

*/

alert(convert.cToF(38));

class Surface {
    constructor(width,height) {
        this.width = width;
        this.height = height;
        this._calculationStrategy = null;
        this.verticalAlignment = 'top';
        this.horizontalAlignment = 'left';
    }


    set calculationStrategy(strategy) {
        if (!strategy instanceof CalculationStrategy) {
            throw 'Strategy must be type of CalculationStrategy';
        }

        this._calculationStrategy = strategy;
    }

    //getNumberToCover
    calculate (targetSurface) {
        if (this._calculationStrategy instanceof CalculationStrategy) {
            throw 'Surface.calculationStrategy must be instance of CalculationStrategy';
        }

        return this._calculationStrategy(targetSurface);
    }

    /**
     * Checks the direction is valid by either matching the height or 
     * the length of the surface and nothing else
     * 
     * @param {*} direction 
     */
    isValidDirection(direction) {
        return direction === "width" || direction === "height";
    }

    /**
     * Checks the number of this Surface instance that could fit on a
     * given direction of the targetSurface
     * 
     * @param {*} targetSurface 
     * @param {*} direction 
     */
    getNumberToSpan(targetSurface, direction) {
        if (!this.isValidDirection(direction)) {
            throw 'Direction must be width or height';
        }
        return targetSurface[direction] / this[direction];
    }

    /**
     * Calculations the minimum number of this Surface instance
     * required to cover targetSurface
     * @param {*} targetSurface 
     */
    getNumberToCover(targetSurface) {
        let width = this.getNumberToSpan(targetSurface, "width");
        let height = this.getNumberToSpan(targetSurface, "height");
        let uncutTiles = Math.trunc(width) * Math.trunc(height);
        return uncutTiles;
    }

    //⍃ ⛋
    getDiamondShape2 (targetSurface){
        let length = this.width;

        let width = targetSurface["width"];
        let height = targetSurface["height"];
        
        let pi = Math.PI;
        
        //calculating using trigonometry the side length
        side = length * Math.cos(pi/4);

        //rounding the answer to 2 decimal places
        halfDiamondLength = Math.round(side * 100) / 100;

        heightNo = Math.ceil(width/halfDiamondLength);
        widthNo = Math.ceil(height/halfDiamondLength);

        noTiles = heightNo * widthNo /2;

        return noTiles
    }
    

}

//defining lazily a feature with a new polygon class
var square = new Feature(new Polygon([[
  [50,20],[50,30],[60,30],[60,20],[50,20]
]]));

var vectorSource = new Vector();

var vectorLayerOptions = {
  source: vectorSource
};
var vectorLayer = new VectorLayer(vectorLayerOptions);

vectorSource.addFeature(square);

function createMap (wallSurface) {
    var wallPoly, wallSource, wallLayer, extent, projection;

    wallPoly = new Feature(
        new Polygon(
            [[
                [0,0],[0,wallSurface.height],[wallSurface.width,wallSurface.height],[wallSurface.width,0],[0,0]
            ]]
        )
    );
    
    wallSource = new Vector();
    wallSource.addFeature(wallPoly);
    wallLayer = new VectorLayer({source: wallSource});
        
    //we project the map by actually nullifying it so we get the empty background 
    extent = [0, 0, wallSurface.width, wallSurface.height];
    projection = new Projection(
        {
            code: 'wall',
            units: 'pixels',
            extent: extent
        }
    );
    
    return new Map(
        {
            target: 'map',
            layers: [wallLayer],
            view: new View(
                {
                    projection: projection,
                    center: [50, 0],
                    zoom: 2
                }
            )
        }
    );
}


window.drawTiles = function (map) {
    var til = new Surface(30, 15);
    var tilePoly, tileSource, tileLayer;
    tileSource = new Vector();
    tileLayer = new VectorLayer({source: tileSource});
    map.addLayer(tileLayer);
    
    var x, y, h=10;
    
    for (x = -h/2; x <= wall.width-(h/2); x+=h) {
        for (y = 0; y <= wall.height; y += h/2) {

            if ((y % 2) && x + h > wall.width) {
                continue;
            }

            tilePoly = new Feature(
                new Polygon(
                    [
                        [
                            [((h/2) * (y % 2))+x, y],
                            [((h/2) * (y % 2))+x+(0.5*h), y+h/2],
                            [((h/2) * (y % 2))+x+h, y],
                            [((h/2) * (y % 2))+x+(0.5*h), y-h/2],
                            [((h/2) * (y % 2))+x, y]
                        ]
                    ]
                )
            );
            
            tileSource.addFeature(tilePoly);
            tileSource.refresh();
        }
    }
};

/**
drawing squared tiles

window.drawTiles = function (map) {
    var til = new Surface(30, 15);
    var tilePoly, tileSource, tileLayer;
    tileSource = new Vector();
    tileLayer = new VectorLayer({source: tileSource});
    map.addLayer(tileLayer);
    
    var x, y, coords;
    for (x = 0; x < wall.width; x+=til.width) {
        for (y = 0; y < wall.height; y += til.height) {
            tilePoly = new Feature(
                new Polygon(
                    [
                        [
                            [x, y],
                            [x, y+til.height],
                            [x+til.width, y+til.height],
                            [x+til.width, y],
                            [x, y]
                        ]
                    ]
                )
            );
            
            tileSource.addFeature(tilePoly);
            tileSource.refresh();
        }
    }
};

var wall = new Surface(300,150);
window.map = createMap(wall);

drawTiles(map);

 */

var wall = new Surface(300,150);
window.map = createMap(wall);

drawTiles(window.map);

// strategies/calculation/calculationstrategy
class CalculationStrategy {
    
};

// strategies/calculation/diamond
class Diamond extends CalculationStrategy {

    calculate (targetSurface) {
        //your stuff here
    }

}

// strategies/calculation/diamond
class Rectangle extends CalculationStrategy {

    calculate (targetSurface) {
        //your stuff here
    }

}

var anaIsTheBest = new Rectangle();
console.log(anaIsTheBest instanceof CalculationStrategy);